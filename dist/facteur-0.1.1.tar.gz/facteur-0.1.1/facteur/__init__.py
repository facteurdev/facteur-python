from .api import Facteur

__all__ = ['Facteur']
